//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright (c) ___YEAR___ ___FULLUSERNAME___ All rights reserved.[EC-2021]
// 

import Foundation

protocol ___VARIABLE_moduleName___ServiceProtocol: AnyObject {
    
}

class ___VARIABLE_moduleName___Service: ___VARIABLE_moduleName___ServiceProtocol {
    
}
